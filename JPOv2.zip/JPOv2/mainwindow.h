/**
 * @file MainWindow.h
 * @brief Plik nagłówkowy klasy MainWindow obsługującej interfejs aplikacji do monitorowania jakości powietrza.
 * @author [Twoje imię]
 * @date [Data utworzenia]
 */

#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QObject>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <QVariantList>
#include <QVariantMap>
#include <QFile>
#include <QDir>
#include <QTimer>

/**
 * @class MainWindow
 * @brief Klasa główna aplikacji odpowiedzialna za komunikację z API GIOŚ oraz zarządzanie danymi stacji pomiarowych.
 *
 * Klasa obsługuje pobieranie danych o stacjach pomiarowych jakości powietrza,
 * sensorach, pomiarach oraz indeksach jakości powietrza z API GIOŚ.
 * Umożliwia także zapisywanie i wczytywanie danych historycznych.
 */
class MainWindow : public QObject
{
    Q_OBJECT
public:
    /**
     * @brief Konstruktor klasy MainWindow.
     * @param parent Wskaźnik na obiekt rodzica (domyślnie nullptr).
     */
    explicit MainWindow(QObject *parent = nullptr);

    /**
     * @brief Destruktor klasy MainWindow.
     */
    ~MainWindow();

    /**
     * @brief Wyszukuje stacje pomiarowe na podstawie podanego tekstu.
     * @param searchText Tekst, według którego filtrowane są stacje.
     */
    Q_INVOKABLE void searchStations(const QString& searchText);

    /**
     * @brief Wyświetla wszystkie dostępne stacje pomiarowe.
     */
    Q_INVOKABLE void showAllStations();

    /**
     * @brief Obsługuje wybór stacji pomiarowej przez użytkownika.
     * @param stationId Identyfikator wybranej stacji.
     */
    Q_INVOKABLE void stationSelected(int stationId);

    /**
     * @brief Obsługuje wybór sensora przez użytkownika.
     * @param sensorId Identyfikator wybranego sensora.
     */
    Q_INVOKABLE void sensorSelected(int sensorId);

    /**
     * @brief Zapisuje aktualnie wyświetlane dane do pliku.
     */
    Q_INVOKABLE void saveCurrentDataToFile();

    /**
     * @brief Wczytuje dane historyczne dla wybranej stacji i sensora.
     * @param stationId Identyfikator stacji.
     * @param sensorId Identyfikator sensora.
     * @param fileInfo Informacja o pliku z danymi historycznymi.
     */
    Q_INVOKABLE void loadHistoricalData(int stationId, int sensorId, const QString& fileInfo);

    /**
     * @brief Pobiera listę dostępnych danych historycznych dla wybranej stacji i sensora.
     * @param stationId Identyfikator stacji.
     * @param sensorId Identyfikator sensora.
     * @return Lista dostępnych plików z danymi historycznymi.
     */
    Q_INVOKABLE QStringList getAvailableHistoricalData(int stationId, int sensorId);

    /**
     * @brief Sprawdza status połączenia sieciowego.
     */
    Q_INVOKABLE void checkNetworkStatus();

signals:
    /**
     * @brief Sygnał emitowany w celu aktualizacji listy stacji w interfejsie użytkownika.
     * @param stations Lista stacji w formacie QVariantList.
     */
    void stationsUpdateRequested(const QVariantList& stations);

    /**
     * @brief Sygnał emitowany w celu aktualizacji informacji o stacji w interfejsie użytkownika.
     * @param info Informacje o stacji.
     */
    void stationInfoUpdateRequested(const QString& info);

    /**
     * @brief Sygnał emitowany w celu aktualizacji listy sensorów w interfejsie użytkownika.
     * @param sensors Lista sensorów w formacie QVariantList.
     */
    void sensorsUpdateRequested(const QVariantList& sensors);

    /**
     * @brief Sygnał emitowany w celu aktualizacji pomiarów w interfejsie użytkownika.
     * @param key Klucz (nazwa parametru) pomiarów.
     * @param values Lista wartości pomiarów.
     */
    void measurementsUpdateRequested(const QString& key, const QVariantList& values);

    /**
     * @brief Sygnał emitowany w celu aktualizacji indeksu jakości powietrza w interfejsie użytkownika.
     * @param text Tekstowa reprezentacja indeksu jakości powietrza.
     * @param color Kolor reprezentujący indeks jakości powietrza.
     */
    void airQualityUpdateRequested(const QString& text, const QString& color);

    /**
     * @brief Sygnał emitowany przy zmianie statusu połączenia sieciowego.
     * @param isOnline Flaga określająca czy połączenie sieciowe jest dostępne.
     */
    void networkStatusChanged(bool isOnline);

    /**
     * @brief Sygnał emitowany po pobraniu listy dostępnych danych historycznych.
     * @param availableFiles Lista dostępnych plików z danymi historycznymi.
     */
    void historicalDataAvailable(const QStringList& availableFiles);

    /**
     * @brief Sygnał emitowany przy zmianie statusu ładowania danych.
     * @param isLoading Flaga określająca czy trwa ładowanie danych.
     */
    void loadingStatusChanged(bool isLoading);

    /**
     * @brief Sygnał emitowany po zakończeniu operacji zapisywania danych.
     * @param success Flaga określająca czy operacja zakończyła się sukcesem.
     * @param message Komunikat dotyczący operacji zapisywania.
     */
    void dataSaveStatusChanged(bool success, const QString& message);

    /**
     * @brief Sygnał emitowany w celu aktualizacji statystyk w interfejsie użytkownika.
     * @param minValue Minimalna wartość pomiarów.
     * @param minDate Data minimalnej wartości.
     * @param maxValue Maksymalna wartość pomiarów.
     * @param maxDate Data maksymalnej wartości.
     * @param avgValue Średnia wartość pomiarów.
     */
    void statisticsUpdateRequested(double minValue, QString minDate, double maxValue, QString maxDate, double avgValue);

private slots:
    /**
     * @brief Slot wywoływany po otrzymaniu odpowiedzi z API dotyczącej stacji pomiarowych.
     */
    void onStationsReceived();

    /**
     * @brief Slot wywoływany po otrzymaniu odpowiedzi z API dotyczącej sensorów.
     */
    void onSensorsReceived();

    /**
     * @brief Slot wywoływany po otrzymaniu odpowiedzi z API dotyczącej pomiarów.
     */
    void onMeasurementsReceived();

    /**
     * @brief Slot wywoływany po otrzymaniu odpowiedzi z API dotyczącej indeksu jakości powietrza.
     */
    void onAirQualityIndexReceived();

private:
    /**
     * @brief Menedżer dostępu do sieci.
     */
    QNetworkAccessManager* networkManager;

    /**
     * @brief Timer do cyklicznego sprawdzania stanu połączenia sieciowego.
     */
    QTimer* networkCheckTimer;

    /**
     * @brief Flaga określająca czy sieć jest dostępna.
     */
    bool isNetworkAccessible;

    /**
     * @brief Bazowy URL API GIOŚ.
     */
    const QString API_BASE_URL = "https://api.gios.gov.pl/pjp-api/rest/";

    /**
     * @brief Endpoint API do pobierania listy stacji.
     */
    const QString API_STATIONS_ENDPOINT = "station/findAll";

    /**
     * @brief Endpoint API do pobierania sensorów dla stacji.
     */
    const QString API_SENSORS_ENDPOINT = "station/sensors/";

    /**
     * @brief Endpoint API do pobierania danych pomiarowych.
     */
    const QString API_MEASUREMENTS_ENDPOINT = "data/getData/";

    /**
     * @brief Endpoint API do pobierania indeksu jakości powietrza.
     */
    const QString API_AIR_QUALITY_ENDPOINT = "aqindex/getIndex/";

    /**
     * @brief Tablica JSON przechowująca informacje o wszystkich stacjach.
     */
    QJsonArray allStations;

    /**
     * @brief Mapa przechowująca informacje o stacjach (klucz: ID stacji).
     */
    QMap<int, QJsonObject> stationsMap;

    /**
     * @brief Mapa przechowująca informacje o sensorach (klucz: ID sensora).
     */
    QMap<int, QJsonObject> sensorsMap;

    /**
     * @brief Obiekt JSON przechowujący aktualne pomiary.
     */
    QJsonObject currentMeasurements;

    /**
     * @brief Identyfikator aktualnie wybranej stacji.
     */
    int currentStationId;

    /**
     * @brief Identyfikator aktualnie wybranego sensora.
     */
    int currentSensorId;

    /**
     * @brief Klucz (nazwa parametru) aktualnych pomiarów.
     */
    QString currentKey;

    /**
     * @brief Lista wartości aktualnych pomiarów.
     */
    QVariantList currentValues;

    /**
     * @brief Katalog przechowywania danych.
     */
    const QString DATA_DIR = "data";

    /**
     * @brief Nazwa pliku przechowującego informacje o stacjach.
     */
    const QString STATIONS_FILE = "stations.json";

    /**
     * @brief Pobiera dane o stacjach pomiarowych z API.
     */
    void fetchStations();

    /**
     * @brief Pobiera dane o sensorach dla wybranej stacji.
     * @param stationId Identyfikator stacji.
     */
    void fetchSensors(int stationId);

    /**
     * @brief Pobiera dane pomiarowe dla wybranego sensora.
     * @param sensorId Identyfikator sensora.
     */
    void fetchMeasurements(int sensorId);

    /**
     * @brief Pobiera indeks jakości powietrza dla wybranej stacji.
     * @param stationId Identyfikator stacji.
     */
    void fetchAirQualityIndex(int stationId);

    /**
     * @brief Przygotowuje dane stacji do wyświetlenia w interfejsie użytkownika.
     * @param stations Tablica JSON zawierająca informacje o stacjach.
     */
    void displayStations(const QJsonArray& stations);

    /**
     * @brief Generuje tekstowy opis stacji pomiarowej.
     * @param station Obiekt JSON zawierający informacje o stacji.
     * @return Tekstowa reprezentacja informacji o stacji.
     */
    QString generateStationInfo(const QJsonObject& station);

    /**
     * @brief Oblicza statystyki dla otrzymanych pomiarów.
     * @param values Lista wartości pomiarów.
     */
    void calculateStatistics(const QVariantList& values);

    /**
     * @brief Zapisuje dane o stacjach do pliku.
     */
    void saveStationsToFile();

    /**
     * @brief Wczytuje dane o stacjach z pliku.
     */
    void loadStationsFromFile();

    /**
     * @brief Zwraca ścieżkę do katalogu z danymi.
     * @return Ścieżka do katalogu z danymi.
     */
    QString getDataDir();

    /**
     * @brief Zwraca ścieżkę do katalogu przechowującego dane dla konkretnej stacji.
     * @param stationId Identyfikator stacji.
     * @return Ścieżka do katalogu stacji.
     */
    QString getStationDir(int stationId);

    /**
     * @brief Zwraca ścieżkę do katalogu przechowującego dane dla konkretnego sensora.
     * @param stationId Identyfikator stacji.
     * @param sensorId Identyfikator sensora.
     * @return Ścieżka do katalogu sensora.
     */
    QString getSensorDir(int stationId, int sensorId);

    /**
     * @brief Generuje nazwę pliku na podstawie bieżącej daty i czasu.
     * @return Nazwa pliku zawierająca datę i czas.
     */
    QString generateFileName();

    /**
     * @brief Sprawdza czy połączenie sieciowe jest dostępne.
     * @return True jeśli sieć jest dostępna, w przeciwnym razie false.
     */
    bool isNetworkAvailable();

    /**
     * @brief Automatycznie zapisuje bieżące dane.
     */
    void autoSaveData();

    /**
     * @brief Wczytuje dane offline, gdy połączenie sieciowe jest niedostępne.
     */
    void loadOfflineData();
};

#endif // MAINWINDOW_H
