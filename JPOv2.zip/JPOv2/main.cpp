/**
 * @file main.cpp
 * @brief Plik główny aplikacji Qt z integracją QML i GUI.
 * @details Plik zawiera funkcję główną aplikacji, która inicjalizuje aplikację Qt,
 * ładuje interfejs QML oraz integruje logikę C++ z QML.
 */

#include <QApplication>                  // Dołączenie klasy do tworzenia aplikacji z GUI opartym na widżetach
#include <QQmlApplicationEngine>         // Dołączenie klasy do ładowania i uruchamiania plików QML
#include <QQmlContext>                   // Dołączenie klasy do udostępniania danych C++ do QML
#include "mainwindow.h"                  // Dołączenie nagłówka z definicją klasy MainWindow

/**
 * @brief Funkcja główna aplikacji.
 * @param argc Liczba argumentów wiersza poleceń.
 * @param argv Tablica argumentów wiersza poleceń.
 * @return Kod zakończenia aplikacji (0 w przypadku sukcesu, -1 w przypadku błędu).
 */
int main(int argc, char *argv[])
{
    QApplication app(argc, argv);        // Utworzenie aplikacji typu QWidget z obsługą GUI

    QQmlApplicationEngine engine;        // Utworzenie silnika do ładowania i uruchamiania QML
    MainWindow mainWindow;               // Utworzenie instancji klasy MainWindow (logika aplikacji)

    // Udostępnienie obiektu mainWindow do QML jako właściwość kontekstowa o nazwie "mainWindow"
    engine.rootContext()->setContextProperty("mainWindow", &mainWindow);

    const QUrl url(QStringLiteral("qrc:/main.qml")); // Ustawienie ścieżki do głównego pliku QML (z zasobów)

    /**
     * @brief Połączenie sygnału utworzenia obiektu QML z obsługą błędu.
     * @details Sprawdza, czy obiekt QML został poprawnie utworzony. W przypadku błędu aplikacja kończy działanie.
     */
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
                         // Sprawdzenie poprawności utworzenia głównego obiektu QML
                         if (!obj && url == objUrl)
                             QCoreApplication::exit(-1); // Zakończenie aplikacji z kodem błędu
                     }, Qt::QueuedConnection);

    engine.load(url); // Załadowanie pliku QML i uruchomienie interfejsu

    /**
     * @brief Sprawdzenie poprawności załadowania pliku QML.
     * @details Jeśli lista obiektów QML jest pusta, aplikacja kończy działanie z kodem błędu.
     */
    if (engine.rootObjects().isEmpty())
        return -1; // Zakończenie aplikacji w przypadku błędu

    return app.exec(); // Uruchomienie głównej pętli zdarzeń aplikacji
}
