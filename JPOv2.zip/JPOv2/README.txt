# Monitor Jakości Powietrza - GIOŚ

## Opis
Aplikacja desktop do monitorowania jakości powietrza w Polsce, wykorzystująca dane z API Głównego Inspektoratu Ochrony Środowiska (GIOŚ). Pozwala na przeglądanie pomiarów z różnych stacji pomiarowych, wizualizację parametrów jakości powietrza oraz archiwizację danych do późniejszego wglądu.

## Funkcje
- Przeglądanie stacji pomiarowych GIOŚ w całej Polsce
- Wyszukiwanie stacji według miejscowości
- Wyświetlanie indeksu jakości powietrza
- Wizualizacja pomiarów dla wybranych parametrów (np. PM10, PM2.5, O3, NO2)
- Wykres historii pomiarów
- Tryb offline z dostępem do zapisanych wcześniej danych
- Automatyczne wykrywanie połączenia z internetem
- Zapisywanie danych pomiarowych do późniejszego użytku


## Wymagania systemowe
- System operacyjny: Windows, macOS lub Linux
- Połączenie internetowe (dla danych online)
- Qt 5.15 lub nowszy

## Autor
Dawid Stanek
