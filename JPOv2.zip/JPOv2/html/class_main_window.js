var class_main_window =
[
    [ "MainWindow", "class_main_window.html#ad26de6668fdf645d615bca9c70ae87ea", null ],
    [ "~MainWindow", "class_main_window.html#ae98d00a93bc118200eeef9f9bba1dba7", null ],
    [ "airQualityUpdateRequested", "class_main_window.html#ad8d2f50fb784bc442f4e974fea9fb8ef", null ],
    [ "checkNetworkStatus", "class_main_window.html#ae9395d62e6e51ee4e34da13f079a1f9a", null ],
    [ "dataSaveStatusChanged", "class_main_window.html#a7cc1fdfa16ccaf1d3d0b3cf72453ed60", null ],
    [ "getAvailableHistoricalData", "class_main_window.html#ab284bc07df0ab5d6fb1e96da0c1c39be", null ],
    [ "historicalDataAvailable", "class_main_window.html#a3df71225d169be2145db5bf765b6ca1c", null ],
    [ "loadHistoricalData", "class_main_window.html#a939606037e62834eea42a7a6b6a3cb4a", null ],
    [ "loadingStatusChanged", "class_main_window.html#a53566e0f704a495a93feeee1d71b761c", null ],
    [ "measurementsUpdateRequested", "class_main_window.html#ac97b6fc242980ff716452f19a8d3a124", null ],
    [ "networkStatusChanged", "class_main_window.html#a36eb27b18db87892e8f42df33ddaada0", null ],
    [ "saveCurrentDataToFile", "class_main_window.html#a4d688b4d40a5013a190891d4c88ad76c", null ],
    [ "searchStations", "class_main_window.html#a0d7997f50343906c1b9f47417664e7bc", null ],
    [ "sensorSelected", "class_main_window.html#a20e7c670ca12f49bd5ae2f85264193e7", null ],
    [ "sensorsUpdateRequested", "class_main_window.html#ab6be409b27cac946e037d9a974869ecc", null ],
    [ "showAllStations", "class_main_window.html#ac404f967c022854028b3aa76b55733c7", null ],
    [ "stationInfoUpdateRequested", "class_main_window.html#a57d2334387e6f052e28ac3cc23b8c563", null ],
    [ "stationSelected", "class_main_window.html#ad5c9232bcaf8b714cf9aa592249a9aa5", null ],
    [ "stationsUpdateRequested", "class_main_window.html#aeb9e402932d3944a632eab45beff9738", null ],
    [ "statisticsUpdateRequested", "class_main_window.html#a60708dacbc57c3b21210b2092d6ef275", null ]
];