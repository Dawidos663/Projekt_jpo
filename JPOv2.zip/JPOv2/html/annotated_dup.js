var annotated_dup =
[
    [ "MainWindow", "class_main_window.html", "class_main_window" ]
];