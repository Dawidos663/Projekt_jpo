var searchData=
[
  ['historicaldataavailable_0',['historicalDataAvailable',['../class_main_window.html#a3df71225d169be2145db5bf765b6ca1c',1,'MainWindow']]]
];
