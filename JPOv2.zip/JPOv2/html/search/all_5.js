var searchData=
[
  ['loadhistoricaldata_0',['loadHistoricalData',['../class_main_window.html#a939606037e62834eea42a7a6b6a3cb4a',1,'MainWindow']]],
  ['loadingstatuschanged_1',['loadingStatusChanged',['../class_main_window.html#a53566e0f704a495a93feeee1d71b761c',1,'MainWindow']]]
];
