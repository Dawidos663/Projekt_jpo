var searchData=
[
  ['getavailablehistoricaldata_0',['getAvailableHistoricalData',['../class_main_window.html#ab284bc07df0ab5d6fb1e96da0c1c39be',1,'MainWindow']]]
];
