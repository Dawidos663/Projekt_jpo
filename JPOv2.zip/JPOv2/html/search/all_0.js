var searchData=
[
  ['airqualityupdaterequested_0',['airQualityUpdateRequested',['../class_main_window.html#ad8d2f50fb784bc442f4e974fea9fb8ef',1,'MainWindow']]]
];
