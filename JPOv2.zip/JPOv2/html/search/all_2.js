var searchData=
[
  ['datasavestatuschanged_0',['dataSaveStatusChanged',['../class_main_window.html#a7cc1fdfa16ccaf1d3d0b3cf72453ed60',1,'MainWindow']]]
];
