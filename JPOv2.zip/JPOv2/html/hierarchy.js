var hierarchy =
[
    [ "QObject", null, [
      [ "MainWindow", "class_main_window.html", null ]
    ] ]
];