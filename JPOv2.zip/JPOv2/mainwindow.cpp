#include "mainwindow.h"
#include <QDebug>
#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QJsonDocument>
#include <QStandardPaths>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QEventLoop>

/**
 * @brief Konstruktor klasy MainWindow
 *
 * Inicjalizacja głównego okna aplikacji, menedżera sieci oraz timera sprawdzającego status połączenia.
 * Utworzenie katalogu danych, wczytanie zapisanych stacji, a następnie próba pobrania świeżych danych z API.
 *
 * @param parent Obiekt rodzica
 */
MainWindow::MainWindow(QObject *parent)
    : QObject(parent), isNetworkAccessible(true), currentStationId(-1), currentSensorId(-1)
{
    networkManager = new QNetworkAccessManager(this);

    // Utworzenie timera do okresowego sprawdzania statusu sieci
    networkCheckTimer = new QTimer(this);
    connect(networkCheckTimer, &QTimer::timeout, this, &MainWindow::checkNetworkStatus);
    networkCheckTimer->start(5000); // Sprawdzanie co 5 sekund

    // Utworzenie katalogu danych jeśli nie istnieje
    QDir dir;
    dir.mkpath(getDataDir());

    // Próba wczytania zapisanych stacji
    loadStationsFromFile();

    // Próba pobrania świeżych danych z API
    fetchStations();
}

/**
 * @brief Destruktor klasy MainWindow
 *
 * Zwolnienie zasobów używanych przez klasę.
 */
MainWindow::~MainWindow()
{
}

/**
 * @brief Sprawdzenie statusu połączenia sieciowego
 *
 * Weryfikacja dostępności połączenia sieciowego oraz emisja sygnału o zmianie statusu.
 * W przypadku odzyskania połączenia - odświeżenie danych, w przypadku utraty - przełączenie na tryb offline.
 */
void MainWindow::checkNetworkStatus()
{
    bool wasOnline = isNetworkAccessible;
    isNetworkAccessible = isNetworkAvailable();

    if (wasOnline != isNetworkAccessible) {
        emit networkStatusChanged(isNetworkAccessible);

        // W przypadku odzyskania połączenia - odświeżenie danych
        if (isNetworkAccessible) {
            fetchStations();
            if (currentStationId > 0) {
                stationSelected(currentStationId);
            }
        } else {
            // W przypadku utraty połączenia - przełączenie na tryb offline
            loadOfflineData();
        }
    }
}

/**
 * @brief Sprawdzenie dostępności połączenia sieciowego
 *
 * Weryfikacja dostępności sieci poprzez próbę połączenia z API GIOŚ
 * lub alternatywnie z serwisem Google.
 *
 * @return Wartość logiczna określająca dostępność połączenia
 */
bool MainWindow::isNetworkAvailable()
{
    // Pierwsza metoda: Sprawdzenie dostępności API GIOŚ
    QNetworkRequest request(QUrl("https://api.gios.gov.pl/pjp-api/rest/station/findAll"));
    QNetworkReply *reply = networkManager->head(request);

    // Oczekiwanie na odpowiedź z timeoutem
    QEventLoop loop;
    QTimer timer;
    timer.setSingleShot(true);
    connect(&timer, &QTimer::timeout, &loop, &QEventLoop::quit);
    connect(reply, &QNetworkReply::finished, &loop, &QEventLoop::quit);
    timer.start(3000); // 3 sekundy timeout
    loop.exec();

    // Sprawdzenie wyniku zapytania
    bool online = false;
    if (timer.isActive()) {
        // Odpowiedź przyszła przed timeoutem
        timer.stop();
        online = (reply->error() == QNetworkReply::NoError ||
                  reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt() == 200 ||
                  reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt() == 301 ||
                  reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt() == 302);
    }
    reply->deleteLater();

    // Próba z innym, ogólnodostępnym adresem jeśli pierwsza metoda nie zadziałała
    if (!online) {
        QNetworkRequest googleRequest(QUrl("https://www.google.com"));
        QNetworkReply *googleReply = networkManager->head(googleRequest);

        QEventLoop googleLoop;
        QTimer googleTimer;
        googleTimer.setSingleShot(true);
        connect(&googleTimer, &QTimer::timeout, &googleLoop, &QEventLoop::quit);
        connect(googleReply, &QNetworkReply::finished, &googleLoop, &QEventLoop::quit);
        googleTimer.start(3000); // 3 sekundy timeout
        googleLoop.exec();

        if (googleTimer.isActive()) {
            googleTimer.stop();
            online = (googleReply->error() == QNetworkReply::NoError);
        }
        googleReply->deleteLater();
    }

    return online;
}

/**
 * @brief Automatyczny zapis danych
 *
 * Zapisanie danych stacji, czujników i pomiarów do plików.
 */
void MainWindow::autoSaveData()
{
    // Automatyczny zapis danych stacji
    if (!allStations.isEmpty()) {
        saveStationsToFile();
    }

    // Automatyczny zapis danych czujników
    if (currentStationId > 0 && !sensorsMap.isEmpty()) {
        QDir dir;
        dir.mkpath(getStationDir(currentStationId));
        QFile file(getStationDir(currentStationId) + "/sensors.json");
        if (file.open(QIODevice::WriteOnly)) {
            QJsonArray sensorsArray;
            for (auto sensor : sensorsMap) {
                sensorsArray.append(sensor);
            }
            file.write(QJsonDocument(sensorsArray).toJson());
            file.close();
        }
    }

    // Dane pomiarów są zapisywane przy każdym pobraniu
    saveCurrentDataToFile();
}

/**
 * @brief Wczytanie danych w trybie offline
 *
 * Wczytanie zapisanych danych stacji, czujników i pomiarów w przypadku braku połączenia z siecią.
 */
void MainWindow::loadOfflineData()
{
    // Wczytanie dostępnych stacji
    loadStationsFromFile();

    // Wczytanie czujników dla wybranej stacji
    if (currentStationId > 0) {
        // Wczytanie zapisanych czujników dla stacji
        QFile file(getStationDir(currentStationId) + "/sensors.json");
        if (file.open(QIODevice::ReadOnly)) {
            QByteArray saveData = file.readAll();
            QJsonDocument doc = QJsonDocument::fromJson(saveData);
            QJsonArray sensors = doc.array();

            QVariantList sensorsList;
            sensorsMap.clear();

            for (const QJsonValue& value : sensors) {
                QJsonObject sensor = value.toObject();
                int id = sensor["id"].toInt();
                QString parameterName = sensor["param"].toObject()["paramName"].toString();
                QString parameterFormula = sensor["param"].toObject()["paramFormula"].toString();
                QString text = QString("%1 (%2)").arg(parameterName, parameterFormula);

                QVariantMap sensorMap;
                sensorMap["display"] = text;
                sensorMap["sensorId"] = id;
                sensorsList.append(sensorMap);

                sensorsMap[id] = sensor;
            }

            emit sensorsUpdateRequested(sensorsList);
            file.close();
        }

        // Wczytanie indeksu jakości powietrza
        QFile aqiFile(getStationDir(currentStationId) + "/aqi.json");
        if (aqiFile.open(QIODevice::ReadOnly)) {
            QByteArray saveData = aqiFile.readAll();
            QJsonDocument doc = QJsonDocument::fromJson(saveData);
            QJsonObject airQuality = doc.object();

            QString indexLevelName = airQuality["stIndexLevel"].toObject()["indexLevelName"].toString();
            QString calcDate = airQuality["stCalcDate"].toString();

            QString text = QString("Indeks jakości powietrza: %1 (dane z: %2) [DANE HISTORYCZNE]")
                               .arg(indexLevelName)
                               .arg(QDateTime::fromString(calcDate, Qt::ISODate).toString("dd.MM.yyyy HH:mm"));

            QString color;
            if (indexLevelName == "Bardzo dobry" || indexLevelName == "Dobry") {
                color = "green";
            } else if (indexLevelName == "Umiarkowany") {
                color = "orange";
            } else {
                color = "red";
            }

            emit airQualityUpdateRequested(text, color);
            aqiFile.close();
        }
    }

    // Wczytanie danych historycznych dla wybranego czujnika
    if (currentStationId > 0 && currentSensorId > 0) {
        QStringList availableFiles = getAvailableHistoricalData(currentStationId, currentSensorId);
        emit historicalDataAvailable(availableFiles);

        // Wczytanie najnowszych dostępnych danych
        if (!availableFiles.isEmpty()) {
            loadHistoricalData(currentStationId, currentSensorId, availableFiles.last());
        }
    }
}

/**
 * @brief Pobranie listy stacji pomiarowych
 *
 * Pobranie listy wszystkich stacji pomiarowych z API GIOŚ lub wczytanie z pliku w trybie offline.
 * Emisja sygnału o zmianie statusu ładowania.
 */
void MainWindow::fetchStations()
{
    emit loadingStatusChanged(true);

    // Wczytanie danych z pliku w przypadku braku połączenia
    if (!isNetworkAccessible) {
        loadStationsFromFile();
        emit loadingStatusChanged(false);
        return;
    }

    QNetworkRequest request((QUrl(API_BASE_URL + API_STATIONS_ENDPOINT)));
    QNetworkReply* reply = networkManager->get(request);
    connect(reply, &QNetworkReply::finished, this, &MainWindow::onStationsReceived);
}

/**
 * @brief Pobranie listy czujników dla wybranej stacji
 *
 * Pobranie listy czujników dla konkretnej stacji z API GIOŚ
 * lub wczytanie z pliku w trybie offline.
 *
 * @param stationId Identyfikator stacji
 */
void MainWindow::fetchSensors(int stationId)
{
    emit loadingStatusChanged(true);

    currentStationId = stationId;

    // Wczytanie danych z pliku w przypadku braku połączenia
    if (!isNetworkAccessible) {
        // Próba wczytania czujników z pliku
        QFile file(getStationDir(stationId) + "/sensors.json");
        if (file.open(QIODevice::ReadOnly)) {
            QByteArray saveData = file.readAll();
            QJsonDocument doc = QJsonDocument::fromJson(saveData);
            QJsonArray sensors = doc.array();

            QVariantList sensorsList;
            sensorsMap.clear();

            for (const QJsonValue& value : sensors) {
                QJsonObject sensor = value.toObject();
                int id = sensor["id"].toInt();
                QString parameterName = sensor["param"].toObject()["paramName"].toString();
                QString parameterFormula = sensor["param"].toObject()["paramFormula"].toString();
                QString text = QString("%1 (%2)").arg(parameterName, parameterFormula);

                QVariantMap sensorMap;
                sensorMap["display"] = text;
                sensorMap["sensorId"] = id;
                sensorsList.append(sensorMap);

                sensorsMap[id] = sensor;
            }

            emit sensorsUpdateRequested(sensorsList);
            file.close();
        }

        // Wczytanie indeksu jakości powietrza z pliku
        QFile aqiFile(getStationDir(stationId) + "/aqi.json");
        if (aqiFile.open(QIODevice::ReadOnly)) {
            QByteArray saveData = aqiFile.readAll();
            QJsonDocument doc = QJsonDocument::fromJson(saveData);
            QJsonObject airQuality = doc.object();

            QString indexLevelName = airQuality["stIndexLevel"].toObject()["indexLevelName"].toString();
            QString calcDate = airQuality["stCalcDate"].toString();

            QString text = QString("Indeks jakości powietrza: %1 (dane z: %2) [DANE HISTORYCZNE]")
                               .arg(indexLevelName)
                               .arg(QDateTime::fromString(calcDate, Qt::ISODate).toString("dd.MM.yyyy HH:mm"));

            QString color;
            if (indexLevelName == "Bardzo dobry" || indexLevelName == "Dobry") {
                color = "green";
            } else if (indexLevelName == "Umiarkowany") {
                color = "orange";
            } else {
                color = "red";
            }

            emit airQualityUpdateRequested(text, color);
            aqiFile.close();
        }

        emit loadingStatusChanged(false);
        return;
    }

    QNetworkRequest request((QUrl(API_BASE_URL + API_SENSORS_ENDPOINT + QString::number(stationId))));
    QNetworkReply* reply = networkManager->get(request);
    connect(reply, &QNetworkReply::finished, this, &MainWindow::onSensorsReceived);
}

/**
 * @brief Pobranie pomiarów z wybranego czujnika
 *
 * Pobranie danych pomiarowych z konkretnego czujnika z API GIOŚ
 * lub wczytanie z pliku w trybie offline.
 *
 * @param sensorId Identyfikator czujnika
 */
void MainWindow::fetchMeasurements(int sensorId)
{
    emit loadingStatusChanged(true);

    currentSensorId = sensorId;

    // Wczytanie danych z pliku w przypadku braku połączenia
    if (!isNetworkAccessible) {
        // Próba pobrania najnowszego pliku z pomiarami
        QStringList availableFiles = getAvailableHistoricalData(currentStationId, sensorId);
        if (!availableFiles.isEmpty()) {
            // Użycie najnowszego pliku (ostatni na liście jeśli posortowany wg daty)
            QString latestFile = availableFiles.last();
            loadHistoricalData(currentStationId, sensorId, latestFile);
        } else {
            emit loadingStatusChanged(false);
        }
        return;
    }

    QNetworkRequest request((QUrl(API_BASE_URL + API_MEASUREMENTS_ENDPOINT + QString::number(sensorId))));
    QNetworkReply* reply = networkManager->get(request);
    connect(reply, &QNetworkReply::finished, this, &MainWindow::onMeasurementsReceived);
}

/**
 * @brief Pobranie indeksu jakości powietrza dla stacji
 *
 * Pobranie danych o indeksie jakości powietrza dla konkretnej stacji z API GIOŚ.
 *
 * @param stationId Identyfikator stacji
 */
void MainWindow::fetchAirQualityIndex(int stationId)
{
    // Dane już załadowano w fetchSensors w przypadku braku połączenia
    if (!isNetworkAccessible) {
        return;
    }

    QNetworkRequest request((QUrl(API_BASE_URL + API_AIR_QUALITY_ENDPOINT + QString::number(stationId))));
    QNetworkReply* reply = networkManager->get(request);
    connect(reply, &QNetworkReply::finished, this, &MainWindow::onAirQualityIndexReceived);
}

/**
 * @brief Obsługa odpowiedzi z API dla listy stacji
 *
 * Przetworzenie odpowiedzi z API zawierającej listę stacji pomiarowych,
 * zapisanie danych do pliku oraz wyświetlenie listy stacji.
 */
void MainWindow::onStationsReceived()
{
    QNetworkReply* reply = qobject_cast<QNetworkReply*>(sender());
    if (!reply) {
        emit loadingStatusChanged(false);
        return;
    }

    if (reply->error() == QNetworkReply::NoError) {
        QByteArray response = reply->readAll();
        QJsonDocument jsonDoc = QJsonDocument::fromJson(response);
        allStations = jsonDoc.array();

        // Zapisanie stacji w mapie dla szybkiego dostępu
        stationsMap.clear();
        for (const QJsonValue& value : allStations) {
            QJsonObject station = value.toObject();
            int id = station["id"].toInt();
            stationsMap[id] = station;
        }

        displayStations(allStations);

        // Zapisanie danych stacji do pliku
        saveStationsToFile();
    } else {
        qDebug() << "Błąd pobierania stacji:" << reply->errorString();
        loadStationsFromFile();
    }

    emit loadingStatusChanged(false);
    reply->deleteLater();
    autoSaveData();
}

/**
 * @brief Obsługa odpowiedzi z API dla listy czujników
 *
 * Przetworzenie odpowiedzi z API zawierającej listę czujników dla wybranej stacji,
 * zapisanie danych do pliku oraz emisja sygnału aktualizacji listy czujników.
 */
void MainWindow::onSensorsReceived()
{
    QNetworkReply* reply = qobject_cast<QNetworkReply*>(sender());
    if (!reply) {
        emit loadingStatusChanged(false);
        return;
    }

    if (reply->error() == QNetworkReply::NoError) {
        QByteArray response = reply->readAll();
        QJsonDocument jsonDoc = QJsonDocument::fromJson(response);
        QJsonArray sensors = jsonDoc.array();

        QVariantList sensorsList;
        sensorsMap.clear();

        for (const QJsonValue& value : sensors) {
            QJsonObject sensor = value.toObject();
            int id = sensor["id"].toInt();
            QString parameterName = sensor["param"].toObject()["paramName"].toString();
            QString parameterFormula = sensor["param"].toObject()["paramFormula"].toString();
            QString text = QString("%1 (%2)").arg(parameterName, parameterFormula);

            QVariantMap sensorMap;
            sensorMap["display"] = text;
            sensorMap["sensorId"] = id;
            sensorsList.append(sensorMap);

            sensorsMap[id] = sensor;
        }

        emit sensorsUpdateRequested(sensorsList);

        // Zapisanie danych czujników do pliku
        QDir dir;
        dir.mkpath(getStationDir(currentStationId));
        QFile file(getStationDir(currentStationId) + "/sensors.json");
        if (file.open(QIODevice::WriteOnly)) {
            file.write(QJsonDocument(sensors).toJson());
            file.close();
        }
    } else {
        qDebug() << "Błąd pobierania czujników:" << reply->errorString();
    }

    emit loadingStatusChanged(false);
    reply->deleteLater();
    autoSaveData();
}

/**
 * @brief Obsługa odpowiedzi z API dla pomiarów z czujnika
 *
 * Przetworzenie odpowiedzi z API zawierającej dane pomiarowe z wybranego czujnika,
 * zapisanie danych do pliku oraz emisja sygnału aktualizacji wykresów.
 */
void MainWindow::onMeasurementsReceived()
{
    QNetworkReply* reply = qobject_cast<QNetworkReply*>(sender());
    if (!reply) {
        emit loadingStatusChanged(false);
        return;
    }

    if (reply->error() == QNetworkReply::NoError) {
        QByteArray response = reply->readAll();
        QJsonDocument jsonDoc = QJsonDocument::fromJson(response);
        QJsonObject measurements = jsonDoc.object();

        currentMeasurements = measurements;
        currentKey = measurements["key"].toString();
        QJsonArray values = measurements["values"].toArray();

        QVariantList valuesList;

        for (const QJsonValue& value : values) {
            QJsonObject measurement = value.toObject();
            QString dateStr = measurement["date"].toString();

            QVariantMap point;
            point["date"] = dateStr;

            // Sprawdzenie czy wartość nie jest nullem i czy jest poprawną liczbą
            if (measurement["value"].isNull()) {
                point["value"] = QVariant();
            } else {
                bool ok;
                double numValue = measurement["value"].toVariant().toDouble(&ok);
                if (ok) {
                    point["value"] = numValue;
                } else {
                    point["value"] = QVariant();
                }
            }

            valuesList.append(point);
        }

        currentValues = valuesList;
        emit measurementsUpdateRequested(currentKey, valuesList);
        calculateStatistics(valuesList);

        // Automatyczny zapis do pliku
        saveCurrentDataToFile();
    } else {
        qDebug() << "Błąd pobierania pomiarów:" << reply->errorString();
    }

    emit loadingStatusChanged(false);
    reply->deleteLater();
    autoSaveData();
}

/**
 * @brief Obsługa odpowiedzi z API dla indeksu jakości powietrza
 *
 * Przetworzenie odpowiedzi z API zawierającej dane o indeksie jakości powietrza,
 * zapisanie danych do pliku oraz emisja sygnału aktualizacji informacji o jakości powietrza.
 */
void MainWindow::onAirQualityIndexReceived()
{
    QNetworkReply* reply = qobject_cast<QNetworkReply*>(sender());
    if (!reply) return;

    if (reply->error() == QNetworkReply::NoError) {
        QByteArray response = reply->readAll();
        QJsonDocument jsonDoc = QJsonDocument::fromJson(response);
        QJsonObject airQuality = jsonDoc.object();

        QString indexLevelName = airQuality["stIndexLevel"].toObject()["indexLevelName"].toString();
        QString calcDate = airQuality["stCalcDate"].toString();

        QString text = QString("Indeks jakości powietrza: %1 (dane z: %2)")
                           .arg(indexLevelName)
                           .arg(QDateTime::fromString(calcDate, Qt::ISODate).toString("dd.MM.yyyy HH:mm"));

        QString color;
        if (indexLevelName == "Bardzo dobry" || indexLevelName == "Dobry") {
            color = "green";
        } else if (indexLevelName == "Umiarkowany") {
            color = "orange";
        } else {
            color = "red";
        }

        emit airQualityUpdateRequested(text, color);

        // Zapisanie danych jakości powietrza do pliku
        QDir dir;
        dir.mkpath(getStationDir(currentStationId));
        QFile file(getStationDir(currentStationId) + "/aqi.json");
        if (file.open(QIODevice::WriteOnly)) {
            file.write(QJsonDocument(airQuality).toJson());
            file.close();
        }
    } else {
        qDebug() << "Błąd pobierania indeksu jakości powietrza:" << reply->errorString();
    }

    reply->deleteLater();
    autoSaveData();
}

/**
 * @brief Obliczenie statystyk z danych pomiarowych
 *
 * Wyliczenie wartości minimalnej, maksymalnej i średniej z listy pomiarów
 * oraz emisja sygnału aktualizacji statystyk.
 *
 * @param values Lista pomiarów do analizy
 */
void MainWindow::calculateStatistics(const QVariantList& values)
{
    double minValue = std::numeric_limits<double>::max();
    double maxValue = std::numeric_limits<double>::lowest();
    double sum = 0.0;
    int validCount = 0;
    QString minDate, maxDate;

    for (const QVariant& pointVar : values) {
        QVariantMap point = pointVar.toMap();
        QVariant valueVariant = point["value"];
        QString dateStr = point["date"].toString();

        if (!valueVariant.isNull() && valueVariant.isValid()) {
            double value = valueVariant.toDouble();
            sum += value;
            validCount++;

            if (value < minValue) {
                minValue = value;
                minDate = QDateTime::fromString(dateStr, Qt::ISODate).toString("dd.MM.yyyy HH:mm");
            }
            if (value > maxValue) {
                maxValue = value;
                maxDate = QDateTime::fromString(dateStr, Qt::ISODate).toString("dd.MM.yyyy HH:mm");
            }
        }
    }

    double avgValue = validCount > 0 ? sum / validCount : 0.0;

    emit statisticsUpdateRequested(minValue, minDate, maxValue, maxDate, avgValue);
}

/**
 * @brief Obsługa wyboru stacji
 *
 * Przetworzenie wyboru stacji przez użytkownika, wyświetlenie informacji o stacji
 * oraz pobranie czujników i indeksu jakości powietrza dla wybranej stacji.
 *
 * @param stationId Identyfikator wybranej stacji
 */
void MainWindow::stationSelected(int stationId)
{
    if (!stationsMap.contains(stationId)) return;

    currentStationId = stationId;
    QJsonObject station = stationsMap[stationId];
    QString info = generateStationInfo(station);
    emit stationInfoUpdateRequested(info);
    fetchSensors(stationId);
    fetchAirQualityIndex(stationId);
}

/**
 * @brief Obsługa wyboru czujnika
 *
 * Przetworzenie wyboru czujnika przez użytkownika, pobranie pomiarów
 * oraz sprawdzenie dostępności danych historycznych dla wybranego czujnika.
 *
 * @param sensorId Identyfikator wybranego czujnika
 */
void MainWindow::sensorSelected(int sensorId)
{
    if (sensorId > 0) {
        currentSensorId = sensorId;
        fetchMeasurements(sensorId);

        // Sprawdzenie dostępności danych historycznych
        QStringList availableFiles = getAvailableHistoricalData(currentStationId, sensorId);
        emit historicalDataAvailable(availableFiles);
    }
}

/**
 * @brief Wyszukiwanie stacji
 *
 * Filtrowanie listy stacji na podstawie wprowadzonego tekstu.
 * Wyszukiwanie po nazwie miasta.
 *
 * @param searchText Tekst do wyszukania
 */
void MainWindow::searchStations(const QString& searchText)
{
    if (searchText.isEmpty()) {
        displayStations(allStations);
        return;
    }

    QJsonArray filteredStations;
    for (const QJsonValue& value : allStations) {
        QJsonObject station = value.toObject();
        QString cityName = station["city"].toObject()["name"].toString().toLower();
        if (cityName.contains(searchText.toLower())) {
            filteredStations.append(station);
        }
    }

    displayStations(filteredStations);
}

/**
 * @brief Wyświetlenie wszystkich stacji
 *
 * Wyświetlenie pełnej listy dostępnych stacji pomiarowych.
 */
void MainWindow::showAllStations()
{
    displayStations(allStations);
}

/**
 * @brief Wyświetlenie listy stacji
 *
 * Przygotowanie danych stacji do wyświetlenia oraz emisja sygnału aktualizacji listy stacji.
 *
 * @param stations Lista stacji do wyświetlenia
 */
void MainWindow::displayStations(const QJsonArray& stations)
{
    QVariantList stationsList;

    for (const QJsonValue& value : stations) {
        QJsonObject station = value.toObject();
        int id = station["id"].toInt();
        QString stationName = station["stationName"].toString();
        QString cityName = station["city"].toObject()["name"].toString();

        QString displayText = QString("%1 - %2").arg(cityName, stationName);

        QVariantMap stationMap;
        stationMap["display"] = displayText;
        stationMap["stationId"] = id;
        stationMap["station"] = station.toVariantMap();
        stationsList.append(stationMap);
    }

    emit stationsUpdateRequested(stationsList);
}
/**
 * @brief Generowanie informacji o stacji pomiarowej
 *
 * Funkcja tworząca sformatowany tekst HTML zawierający szczegóły stacji na podstawie danych JSON.
 *
 * @param station Obiekt JSON zawierający dane stacji
 * @return Sformatowany tekst HTML z informacjami o stacji
 */
QString MainWindow::generateStationInfo(const QJsonObject& station)
{
    QString stationName = station["stationName"].toString();
    QJsonObject city = station["city"].toObject();
    QString cityName = city["name"].toString();
    QString street = station["addressStreet"].toString();

    QJsonObject commune = city["commune"].toObject();
    QString communeName = commune["communeName"].toString();
    QString districtName = commune["districtName"].toString();
    QString provinceName = commune["provinceName"].toString();

    double lat = station["gegrLat"].toString().toDouble();
    double lon = station["gegrLon"].toString().toDouble();

    QString info = QString("<h3>%1</h3>").arg(stationName) +
                   QString("<p><b>Miasto:</b> %1</p>").arg(cityName) +
                   QString("<p><b>Ulica:</b> %1</p>").arg(street) +
                   QString("<p><b>Gmina:</b> %1</p>").arg(communeName) +
                   QString("<p><b>Powiat:</b> %1</p>").arg(districtName) +
                   QString("<p><b>Województwo:</b> %1</p>").arg(provinceName) +
                   QString("<p><b>Współrzędne:</b> %1, %2</p>").arg(lat).arg(lon);

    return info;
}

/**
 * @brief Zapisywanie listy stacji do pliku
 *
 * Funkcja zapisująca dane wszystkich stacji w formacie JSON do pliku.
 * Tworzy katalog danych jeśli nie istnieje.
 */
void MainWindow::saveStationsToFile()
{
    QDir dir;
    dir.mkpath(getDataDir());

    QFile file(getDataDir() + "/" + STATIONS_FILE);
    if (file.open(QIODevice::WriteOnly)) {
        file.write(QJsonDocument(allStations).toJson());
        file.close();
        qDebug() << "Stations saved to file:" << file.fileName();
    } else {
        qDebug() << "Failed to save stations to file:" << file.fileName();
    }
}

/**
 * @brief Wczytywanie listy stacji z pliku
 *
 * Funkcja odczytująca dane stacji z pliku JSON i zapisująca je do pamięci aplikacji.
 * Dane są przechowywane w dwóch strukturach: tablicy JSON oraz w mapie dla szybkiego dostępu.
 */
void MainWindow::loadStationsFromFile()
{
    QFile file(getDataDir() + "/" + STATIONS_FILE);
    if (file.open(QIODevice::ReadOnly)) {
        QByteArray saveData = file.readAll();
        QJsonDocument doc = QJsonDocument::fromJson(saveData);
        allStations = doc.array();

        // Store stations in map for quick access
        stationsMap.clear();
        for (const QJsonValue& value : allStations) {
            QJsonObject station = value.toObject();
            int id = station["id"].toInt();
            stationsMap[id] = station;
        }

        displayStations(allStations);
        file.close();
        qDebug() << "Stations loaded from file:" << file.fileName();
    } else {
        qDebug() << "No stations file found at:" << file.fileName();
    }
}

/**
 * @brief Pobieranie ścieżki katalogu danych aplikacji
 *
 * @return Ścieżka do katalogu przechowywania danych aplikacji
 */
QString MainWindow::getDataDir()
{
    return QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + "/" + DATA_DIR;
}

/**
 * @brief Pobieranie ścieżki katalogu dla konkretnej stacji
 *
 * @param stationId Identyfikator stacji
 * @return Ścieżka do katalogu danych konkretnej stacji
 */
QString MainWindow::getStationDir(int stationId)
{
    return getDataDir() + "/" + QString::number(stationId);
}

/**
 * @brief Pobieranie ścieżki katalogu dla konkretnego czujnika
 *
 * @param stationId Identyfikator stacji
 * @param sensorId Identyfikator czujnika
 * @return Ścieżka do katalogu danych konkretnego czujnika
 */
QString MainWindow::getSensorDir(int stationId, int sensorId)
{
    return getStationDir(stationId) + "/" + QString::number(sensorId);
}

/**
 * @brief Generowanie nazwy pliku na podstawie aktualnej daty i czasu
 *
 * @return Nazwa pliku w formacie "yyyy-MM-dd_HH-mm-ss.json"
 */
QString MainWindow::generateFileName()
{
    QDateTime now = QDateTime::currentDateTime();
    return now.toString("yyyy-MM-dd_HH-mm-ss") + ".json";
}

/**
 * @brief Zapisywanie aktualnych danych pomiarowych do pliku
 *
 * Funkcja zapisuje aktualnie wyświetlane dane pomiarowe do pliku JSON.
 * Tworzy odpowiednią strukturę katalogów jeśli nie istnieje.
 * Emituje sygnał z informacją o powodzeniu lub niepowodzeniu operacji.
 */
void MainWindow::saveCurrentDataToFile()
{
    if (currentStationId <= 0 || currentSensorId <= 0 || currentMeasurements.isEmpty()) {
        return;
    }

    QDir dir;
    dir.mkpath(getSensorDir(currentStationId, currentSensorId));

    QString filePath = getSensorDir(currentStationId, currentSensorId) + "/" + generateFileName();

    QFile file(filePath);
    if (file.open(QIODevice::WriteOnly)) {
        file.write(QJsonDocument(currentMeasurements).toJson());
        file.close();
        emit dataSaveStatusChanged(true, QString("Dane zapisane pomyślnie do pliku: %1").arg(QFileInfo(file).fileName()));
        qDebug() << "Measurements saved to file:" << file.fileName();
    } else {
        emit dataSaveStatusChanged(false, "Błąd podczas zapisywania danych");
        qDebug() << "Failed to save measurements to file:" << file.fileName();
    }
}

/**
 * @brief Pobieranie listy dostępnych historycznych danych dla danego czujnika
 *
 * Funkcja przeszukuje katalog z danymi czujnika i zwraca listę dostępnych plików
 * z pomiarami historycznymi w formacie czytelnym dla użytkownika.
 *
 * @param stationId Identyfikator stacji
 * @param sensorId Identyfikator czujnika
 * @return Lista dostępnych plików z danymi historycznymi w formacie "data_wyświetlana:nazwa_pliku"
 */
QStringList MainWindow::getAvailableHistoricalData(int stationId, int sensorId)
{
    QStringList result;

    QDir dir(getSensorDir(stationId, sensorId));
    if (!dir.exists()) {
        return result;
    }

    QStringList filters;
    filters << "*.json";
    dir.setNameFilters(filters);

    QStringList fileList = dir.entryList(filters, QDir::Files, QDir::Name);

    // Add each file to the list with date info
    for (const QString& file : fileList) {
        // Parse date from filename (yyyy-MM-dd_HH-mm-ss.json)
        QString dateStr = file;
        dateStr.chop(5); // Remove .json
        QDateTime dateTime = QDateTime::fromString(dateStr, "yyyy-MM-dd_HH-mm-ss");

        if (dateTime.isValid()) {
            QString displayName = dateTime.toString("dd.MM.yyyy HH:mm:ss");
            result.append(displayName + ":" + file);
        }
    }

    return result;
}

/**
 * @brief Wczytywanie historycznych danych pomiarowych
 *
 * Funkcja wczytująca dane historyczne z wybranego pliku i wyświetlająca je na wykresie.
 * Emituje sygnały informujące o statusie wczytywania i aktualizacji wykresu.
 *
 * @param stationId Identyfikator stacji
 * @param sensorId Identyfikator czujnika
 * @param fileInfo Informacja o pliku w formacie "data_wyświetlana:nazwa_pliku"
 */
void MainWindow::loadHistoricalData(int stationId, int sensorId, const QString& fileInfo)
{
    emit loadingStatusChanged(true);

    // Parse filename from display info
    QString fileName;
    if (fileInfo.contains(":")) {
        fileName = fileInfo.split(":").at(1);
    } else {
        fileName = fileInfo; // Jeśli nie ma separatora ":", to cały string jest nazwą pliku
    }

    QString filePath = getSensorDir(stationId, sensorId) + "/" + fileName;

    QFile file(filePath);
    if (file.open(QIODevice::ReadOnly)) {
        QByteArray saveData = file.readAll();
        QJsonDocument doc = QJsonDocument::fromJson(saveData);
        QJsonObject measurements = doc.object();

        QString key = measurements["key"].toString();
        QJsonArray values = measurements["values"].toArray();

        QVariantList valuesList;

        for (const QJsonValue& value : values) {
            QJsonObject measurement = value.toObject();
            QString dateStr = measurement["date"].toString();
            QVariant valueVariant = measurement["value"].toVariant();

            QVariantMap point;
            point["date"] = dateStr;
            point["value"] = valueVariant.isNull() ? QVariant() : valueVariant.toDouble();
            valuesList.append(point);
        }

        // Display with notification that these are historical data
        QString historicalKey = key + " [DANE HISTORYCZNE]";
        emit measurementsUpdateRequested(historicalKey, valuesList);
        calculateStatistics(valuesList);

        file.close();
        qDebug() << "Historical data loaded from file:" << file.fileName();
    } else {
        qDebug() << "Failed to load historical data from file:" << filePath;
    }

    emit loadingStatusChanged(false);
}
